﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassCarshare;

namespace WpfApp6
{
    /// <summary>
    /// Логика взаимодействия для UserProfile.xaml
    /// </summary>
    public partial class UserProfile : Window
    {
        
        public event Action Iwanttogoout;
        Repository _repo = Factory.Instance.GetRepository();
        public UserProfile()
        {
            InitializeComponent();
        }


        private void Thereisnoneedtodrive()
        {
            Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var carshare = new Window1();
            carshare.Noneed4cars += Thereisnoneedtodrive;
            carshare.Show();

            Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Iwanttogoout?.Invoke();
            Close();
        }
    }
}
