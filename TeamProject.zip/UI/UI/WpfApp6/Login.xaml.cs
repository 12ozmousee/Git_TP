﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassCarshare;

namespace WpfApp6
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }
        Repository _repo = Factory.Instance.GetRepository();

        private void BtnClickP1(object sender, RoutedEventArgs e)
        {

            if (_repo.Authorize(txtemail.Text, txtpassword.Password))
            {
                var userwindow = new UserProfile();
                userwindow.Show();
                Hide();
                userwindow.Iwanttogoout += UserProfile_Leaves;
            }
            else
            {
                MessageBox.Show("Incorrect login/password");
            }
        }
        private void BtnClickP2(object sender, RoutedEventArgs e)
        {
            var register = new Registration();
            register.RegistrationFinished += RegisterWindow_RegistrationFinished;
            register.Show();

            Hide();
        }
        private void RegisterWindow_RegistrationFinished()
        {
            Show();
        }
        private void UserProfile_Leaves()
        {
            Show();
        }
    }

}
