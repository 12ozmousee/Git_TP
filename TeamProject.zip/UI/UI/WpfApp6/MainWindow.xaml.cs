﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassCarshare;

namespace WpfApp6
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public event Action Noneed4cars;
        Repository _repo = Factory.Instance.GetRepository();
        public Window1()

        {
            InitializeComponent();
            ListViewerCar.ItemsSource = _repo.YouRule();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Noneed4cars?.Invoke();
            Close();
        }
    }

}
