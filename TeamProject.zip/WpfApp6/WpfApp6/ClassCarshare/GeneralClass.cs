﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassCarshare
{
    public class GeneralClass
    {
        public List<User> Users { get; set; }
        public List<CarShare> CarShares { get; set; }
        
    }
}
