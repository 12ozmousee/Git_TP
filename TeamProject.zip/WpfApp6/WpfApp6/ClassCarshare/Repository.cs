﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

namespace ClassCarshare
{
   public class Repository

    {
       




        public GeneralClass Load(string gb)
        {
            var ob = JsonConvert.DeserializeObject<GeneralClass>(gb);
            return ob;
        }

        public static GeneralClass Dataload()
        {

            return JsonConvert.DeserializeObject<GeneralClass>(new StreamReader(FileName).ReadToEnd());
        }

        private const string DataFolder = "..//..//..//WpfApp6//WpfApp6//ClassCarshare//Data";
        private const string FileName = "Carshering.json";

        private GeneralClass _GeneralClass;
		private User _authorizedUser;

        public void Save()
        {
            if (!Directory.Exists(DataFolder))
            {
                Directory.CreateDirectory(DataFolder);
            }
            using (var sw = new StreamWriter(Path.Combine(DataFolder, FileName)))
            {
                using (var jsonWriter = new JsonTextWriter(sw))
                {
                    var serializer = new JsonSerializer();
                    serializer.Serialize(jsonWriter, _GeneralClass);
                }
            }
        }

        public Repository()
        {
            try
            {
                using (var sr = new StreamReader(Path.Combine(DataFolder, FileName)))
                {
                    using (var jsonReader = new JsonTextReader(sr))
                    {
                        var serializer = new JsonSerializer();
                        _GeneralClass = serializer.Deserialize<GeneralClass>(jsonReader);
                    }
                }

            }
            catch
            {
                
                _GeneralClass = new GeneralClass
                {
                    Users = new List<User>(),
                    CarShares = new List<CarShare>(),
                    
                };
            }
        }

        public void RegisterUser(User user)
        {
            user.Id = _GeneralClass.Users.Count > 0 ? _GeneralClass.Users.Max(u => u.Id) + 1 : 1;
            _GeneralClass.Users.Add(user);
            Save();
        }
        public bool Authorize(string login, string password)
        {
            var user = _GeneralClass.Users.FirstOrDefault(u => u.Login == login && u.Password == Hash.GetHash(password));
            if (user != null)
            {
               _authorizedUser = user;
                return true;
            }
            return false;
        }

        public List<CarShare> YouRule ()
        {
            List<CarShare> access = new List<CarShare>();
            DateTime curdt = DateTime.Now;
             
             
            foreach (var carshare in _GeneralClass.CarShares)
            {
                var minage = carshare.MinimalAge;
                var minlicense = carshare.MinimalLisence;
                var age = _authorizedUser.DOB;
                var license = _authorizedUser.LicenseDate;
                int year = curdt.Year - age.Year;
                int yearlic = curdt.Year - license.Year;
                if (curdt.Month < age.Month ||
                (curdt.Month == age.Month && curdt.Day <age.Day)) year--;
                if (curdt.Month < license.Month ||
                (curdt.Month == license.Month && curdt.Day < license.Day)) yearlic--;
                if (year>=minage&& yearlic>=minlicense)
                {
                    access.Add(new CarShare
                    {
                        Company = carshare.Company,
                        
                        MinimalAge=carshare.MinimalAge,
                        MinimalLisence=carshare.MinimalLisence,
                        AdditionalInfo=carshare.AdditionalInfo
                    }
                        );

                }
            } return access;
        }













    }
}
